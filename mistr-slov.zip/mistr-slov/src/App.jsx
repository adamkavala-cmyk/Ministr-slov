import { useState, useEffect, useCallback, useRef } from "react";

const CATEGORY_COLORS = {
  B: { bg: "#fce7f3", border: "#f9a8d4", text: "#9d174d", dot: "#ec4899", label: "Skupina B" },
  L: { bg: "#fef3c7", border: "#fcd34d", text: "#92400e", dot: "#f59e0b", label: "Skupina L" },
  M: { bg: "#d1fae5", border: "#6ee7b7", text: "#064e3b", dot: "#10b981", label: "Skupina M" },
  P: { bg: "#dbeafe", border: "#93c5fd", text: "#1e3a8a", dot: "#3b82f6", label: "Skupina P" },
  S: { bg: "#ede9fe", border: "#c4b5fd", text: "#4c1d95", dot: "#8b5cf6", label: "Skupina S" },
  V: { bg: "#fce7f3", border: "#f9a8d4", text: "#831843", dot: "#db2777", label: "Skupina V" },
  Z: { bg: "#ccfbf1", border: "#5eead4", text: "#134e4a", dot: "#14b8a6", label: "Skupina Z" },
};

const LEVEL1_OPTIONS = ["i", "y"];
const LEVEL2_OPTIONS = ["i", "í", "y", "ý"];

function shuffle(arr) {
  const a = [...arr];
  for (let i = a.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [a[i], a[j]] = [a[j], a[i]];
  }
  return a;
}

function getLevel1Answer(correct) {
  return correct.replace(/[íý]/g, c => c === "í" ? "i" : "y");
}

function ConfettiPiece({ style }) {
  return <div style={style} />;
}

function Confetti() {
  const pieces = Array.from({ length: 18 }, (_, i) => {
    const colors = ["#6366f1","#f59e0b","#10b981","#ec4899","#3b82f6","#f97316"];
    return {
      key: i,
      style: {
        position: "fixed",
        top: `${Math.random() * 30}%`,
        left: `${Math.random() * 100}%`,
        width: `${8 + Math.random() * 10}px`,
        height: `${8 + Math.random() * 10}px`,
        borderRadius: Math.random() > 0.5 ? "50%" : "2px",
        backgroundColor: colors[i % colors.length],
        animation: `confetti-fall ${0.8 + Math.random() * 0.6}s ease forwards`,
        animationDelay: `${Math.random() * 0.3}s`,
        zIndex: 100,
        pointerEvents: "none",
      }
    };
  });
  return <>{pieces.map(p => <ConfettiPiece key={p.key} style={p.style} />)}</>;
}

export default function App() {
  const [allWords, setAllWords] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [level, setLevel] = useState(1);
  const [settingsOpen, setSettingsOpen] = useState(false);
  const [queue, setQueue] = useState([]);
  const [current, setCurrent] = useState(0);
  const [score, setScore] = useState(0);
  const [streak, setStreak] = useState(0);
  const [maxStreak, setMaxStreak] = useState(0);
  const [feedback, setFeedback] = useState(null);
  const [showExplanation, setShowExplanation] = useState(false);
  const [answered, setAnswered] = useState(false);
  const [total, setTotal] = useState(0);
  const [finished, setFinished] = useState(false);
  const [celebrating, setCelebrating] = useState(false);
  const [cardAnim, setCardAnim] = useState("");
  const [selectedFilter, setSelectedFilter] = useState("ALL");
  const timeoutRef = useRef(null);

  useEffect(() => {
    fetch("./words.json")
      .then(r => r.json())
      .then(data => {
        setAllWords(data);
        setQueue(shuffle(data));
        setLoading(false);
      })
      .catch(() => setError("Nepodařilo se načíst slova."));
  }, []);

  const word = queue[current];
  const cat = word ? CATEGORY_COLORS[word.kategorie] : null;

  const getCorrect = useCallback((w) => {
    if (!w) return "";
    if (level === 1) return getLevel1Answer(w.spravnaVazba);
    return w.spravnaVazba;
  }, [level]);

  const applyFilter = useCallback((words, filter) => {
    if (filter === "ALL") return words;
    return words.filter(w => w.kategorie === filter);
  }, []);

  const restartWith = useCallback((words, filter) => {
    const filtered = applyFilter(words, filter);
    setQueue(shuffle(filtered));
    setCurrent(0); setScore(0); setStreak(0); setMaxStreak(0);
    setFeedback(null); setShowExplanation(false); setAnswered(false);
    setTotal(0); setFinished(false); setCelebrating(false);
  }, [applyFilter]);

  const handleAnswer = (choice) => {
    if (answered || !word) return;
    const correct = getCorrect(word);
    const isCorrect = choice === correct;
    setAnswered(true);
    setTotal(t => t + 1);
    setFeedback(isCorrect ? "correct" : "wrong");
    setCardAnim(isCorrect ? "anim-celebrate" : "anim-shake");
    setTimeout(() => setCardAnim(""), 500);

    if (isCorrect) {
      setScore(s => s + 1);
      const newStreak = streak + 1;
      setStreak(newStreak);
      if (newStreak > maxStreak) setMaxStreak(newStreak);
      if (newStreak > 0 && newStreak % 5 === 0) {
        setCelebrating(true);
        setTimeout(() => setCelebrating(false), 1400);
      }
      timeoutRef.current = setTimeout(() => nextWord(), 950);
    } else {
      setStreak(0);
      setShowExplanation(true);
    }
  };

  const nextWord = () => {
    if (current + 1 >= queue.length) { setFinished(true); return; }
    setCurrent(c => c + 1);
    setFeedback(null); setShowExplanation(false); setAnswered(false);
    setCardAnim("anim-slide-up");
    setTimeout(() => setCardAnim(""), 300);
  };

  const progress = queue.length > 0 ? Math.round((current / queue.length) * 100) : 0;
  const accuracy = total > 0 ? Math.round((score / total) * 100) : 0;

  if (loading) return (
    <div style={{ minHeight: "100dvh", display: "flex", alignItems: "center", justifyContent: "center", background: "var(--c-bg)" }}>
      <div style={{ textAlign: "center" }}>
        <div style={{ fontSize: 56, marginBottom: 16 }} className="anim-float">📚</div>
        <p style={{ fontFamily: "var(--font-display)", fontSize: 20, color: "var(--c-primary)" }}>Načítám slova…</p>
      </div>
    </div>
  );

  if (error) return (
    <div style={{ minHeight: "100dvh", display: "flex", alignItems: "center", justifyContent: "center", background: "var(--c-bg)", padding: 24 }}>
      <div style={{ background: "white", borderRadius: 24, padding: 32, textAlign: "center", maxWidth: 320 }}>
        <div style={{ fontSize: 48, marginBottom: 12 }}>😕</div>
        <p style={{ color: "#ef4444", fontWeight: 700 }}>{error}</p>
        <p style={{ color: "#64748b", marginTop: 8, fontSize: 14 }}>Zkus obnovit stránku.</p>
      </div>
    </div>
  );

  if (finished) return (
    <div style={{ minHeight: "100dvh", display: "flex", alignItems: "center", justifyContent: "center", background: "var(--c-bg)", padding: 16 }}>
      {celebrating && <Confetti />}
      <div style={{ background: "white", borderRadius: 32, padding: "36px 28px", maxWidth: 380, width: "100%", textAlign: "center", boxShadow: "0 8px 40px rgba(99,102,241,0.15)" }} className="anim-pop">
        <div style={{ fontSize: 72, marginBottom: 8 }}>🎓</div>
        <h2 style={{ fontFamily: "var(--font-display)", fontSize: 32, color: "#1e293b", marginBottom: 4 }}>Výborně!</h2>
        <p style={{ color: "#64748b", marginBottom: 28 }}>Procvičil jsi {queue.length} slov</p>
        <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr 1fr", gap: 12, marginBottom: 28 }}>
          {[
            { val: score, label: "správně", bg: "#dcfce7", color: "#166534" },
            { val: `${accuracy}%`, label: "úspěšnost", bg: "#e0e7ff", color: "#3730a3" },
            { val: maxStreak, label: "max. série", bg: "#fef3c7", color: "#92400e" },
          ].map(s => (
            <div key={s.label} style={{ background: s.bg, borderRadius: 16, padding: "12px 8px" }}>
              <div style={{ fontSize: 26, fontWeight: 900, color: s.color }}>{s.val}</div>
              <div style={{ fontSize: 11, color: s.color, opacity: 0.8 }}>{s.label}</div>
            </div>
          ))}
        </div>
        <button
          onClick={() => restartWith(allWords, selectedFilter)}
          style={{ width: "100%", background: "linear-gradient(135deg, #6366f1, #8b5cf6)", color: "white", fontWeight: 800, fontSize: 17, padding: "16px", borderRadius: 18, display: "flex", alignItems: "center", justifyContent: "center", gap: 8 }}
        >
          🔄 Hrát znovu
        </button>
      </div>
    </div>
  );

  if (!word) return null;

  const sentenceParts = word.kontextovaVeta.split("_");
  const correct = getCorrect(word);

  return (
    <div style={{
      minHeight: "100dvh",
      background: feedback === "correct" ? "linear-gradient(135deg, #f0fdf4, #dcfce7)" :
                  feedback === "wrong" ? "linear-gradient(135deg, #fff1f2, #fee2e2)" :
                  "linear-gradient(135deg, #f0f4ff, #e8eeff, #f5f0ff)",
      transition: "background 0.4s ease",
      display: "flex", flexDirection: "column",
    }}>
      {celebrating && <Confetti />}

      {/* Header */}
      <header style={{ padding: "16px 16px 8px", maxWidth: 480, margin: "0 auto", width: "100%", display: "flex", alignItems: "center", justifyContent: "space-between" }}>
        <div>
          <div style={{ fontFamily: "var(--font-display)", fontSize: 22, color: "#1e293b", lineHeight: 1.1 }}>Mistr</div>
          <div style={{ fontFamily: "var(--font-display)", fontSize: 22, color: "var(--c-primary)", lineHeight: 1.1, marginTop: -2 }}>vyjmenovaných</div>
        </div>
        <div style={{ display: "flex", alignItems: "center", gap: 10 }}>
          {streak >= 3 && (
            <div style={{ display: "flex", alignItems: "center", gap: 4, background: "#fef3c7", borderRadius: 20, padding: "5px 10px" }}>
              <span style={{ fontSize: 14 }}>⚡</span>
              <span style={{ fontSize: 13, fontWeight: 800, color: "#92400e" }}>{streak}</span>
            </div>
          )}
          <div style={{ display: "flex", alignItems: "center", gap: 4, background: "#e0e7ff", borderRadius: 20, padding: "5px 10px" }}>
            <span style={{ fontSize: 14 }}>⭐</span>
            <span style={{ fontSize: 13, fontWeight: 800, color: "#3730a3" }}>{score}</span>
          </div>
          <button
            onClick={() => setSettingsOpen(true)}
            style={{ width: 38, height: 38, borderRadius: "50%", background: "white", boxShadow: "0 2px 8px rgba(0,0,0,0.10)", display: "flex", alignItems: "center", justifyContent: "center", fontSize: 18, color: "#64748b" }}
          >⚙️</button>
        </div>
      </header>

      {/* Progress */}
      <div style={{ padding: "0 16px", maxWidth: 480, margin: "0 auto", width: "100%" }}>
        <div style={{ display: "flex", justifyContent: "space-between", fontSize: 12, color: "#94a3b8", marginBottom: 6 }}>
          <span>{current + 1} / {queue.length}</span>
          <span>{accuracy}% správně</span>
        </div>
        <div style={{ height: 8, background: "rgba(255,255,255,0.7)", borderRadius: 8, overflow: "hidden" }}>
          <div style={{ height: "100%", width: `${progress}%`, background: "linear-gradient(90deg, #6366f1, #8b5cf6)", borderRadius: 8, transition: "width 0.5s ease" }} />
        </div>
      </div>

      {/* Content */}
      <main style={{ flex: 1, padding: "12px 16px 24px", maxWidth: 480, margin: "0 auto", width: "100%", display: "flex", flexDirection: "column", gap: 12 }}>
        {/* Category badge */}
        <div style={{ display: "flex", alignItems: "center", gap: 8 }}>
          <span style={{ display: "inline-flex", alignItems: "center", gap: 6, padding: "5px 12px", borderRadius: 20, fontSize: 13, fontWeight: 800, background: cat.bg, color: cat.text, border: `1.5px solid ${cat.border}` }}>
            <span style={{ width: 8, height: 8, borderRadius: "50%", background: cat.dot, display: "inline-block" }} />
            {cat.label}
          </span>
          <span style={{ fontSize: 22 }}>{word.emoji}</span>
        </div>

        {/* Sentence card */}
        <div
          className={cardAnim}
          style={{
            background: feedback === "correct" ? "#f0fdf4" : feedback === "wrong" ? "#fff1f2" : "white",
            border: feedback === "correct" ? "2px solid #86efac" : feedback === "wrong" ? "2px solid #fca5a5" : "2px solid rgba(255,255,255,0)",
            borderRadius: 24, padding: "24px 20px", boxShadow: "0 4px 24px rgba(99,102,241,0.10)",
            transition: "all 0.3s ease",
          }}
        >
          <p style={{ fontSize: 24, fontWeight: 800, color: "#1e293b", lineHeight: 1.5, textAlign: "center", fontFamily: "var(--font-body)" }}>
            {sentenceParts[0]}
            <span style={{
              display: "inline-flex", alignItems: "center", justifyContent: "center",
              minWidth: 36, padding: "0 6px", margin: "0 2px",
              borderRadius: 10,
              background: answered ? (feedback === "correct" ? "#22c55e" : "#ef4444") : "rgba(99,102,241,0.08)",
              color: answered ? "white" : "#94a3b8",
              fontWeight: 900, fontSize: 26,
              borderBottom: answered ? "none" : "3px solid #c7d2fe",
              transition: "all 0.25s",
              transform: answered && feedback === "correct" ? "scale(1.1)" : "scale(1)",
            }}>
              {answered ? correct : "__"}
            </span>
            {sentenceParts[1]}
          </p>

          {feedback === "correct" && (
            <p style={{ textAlign: "center", color: "#16a34a", fontWeight: 700, fontSize: 15, marginTop: 10 }}>✅ Správně!</p>
          )}
          {feedback === "wrong" && (
            <p style={{ textAlign: "center", color: "#dc2626", fontWeight: 700, fontSize: 15, marginTop: 10 }}>
              ❌ Správně je: <strong style={{ fontSize: 18 }}>{correct}</strong>
            </p>
          )}
        </div>

        {/* Explanation */}
        {showExplanation && (
          <div style={{ background: "#fffbeb", border: "1.5px solid #fde68a", borderRadius: 18, padding: "14px 16px" }} className="anim-slide-up">
            <p style={{ fontSize: 14, fontWeight: 600, color: "#92400e", lineHeight: 1.5 }}>
              💡 {word.oduvodneni}
            </p>
          </div>
        )}

        {/* Answer buttons */}
        {!answered && (
          <div style={{ display: "grid", gridTemplateColumns: level === 2 ? "1fr 1fr" : "1fr 1fr", gap: 12, marginTop: 4 }}>
            {(level === 1 ? LEVEL1_OPTIONS : LEVEL2_OPTIONS).map(opt => (
              <button
                key={opt}
                onClick={() => handleAnswer(opt)}
                style={{
                  background: "white",
                  border: "2.5px solid #e2e8f0",
                  borderRadius: 20,
                  padding: "20px 16px",
                  fontSize: 32,
                  fontWeight: 900,
                  color: "#334155",
                  fontFamily: "var(--font-body)",
                  boxShadow: "0 2px 10px rgba(0,0,0,0.06)",
                  transition: "all 0.15s",
                  WebkitTapHighlightColor: "transparent",
                }}
                onMouseEnter={e => { e.currentTarget.style.background = "#e0e7ff"; e.currentTarget.style.borderColor = "#6366f1"; e.currentTarget.style.transform = "scale(1.04)"; }}
                onMouseLeave={e => { e.currentTarget.style.background = "white"; e.currentTarget.style.borderColor = "#e2e8f0"; e.currentTarget.style.transform = "scale(1)"; }}
              >
                {opt}
              </button>
            ))}
          </div>
        )}

        {/* Next button */}
        {answered && feedback === "wrong" && (
          <button
            onClick={nextWord}
            className="anim-slide-up"
            style={{ background: "linear-gradient(135deg, #6366f1, #8b5cf6)", color: "white", fontWeight: 800, fontSize: 17, padding: "16px", borderRadius: 20, display: "flex", alignItems: "center", justifyContent: "center", gap: 8, boxShadow: "0 4px 16px rgba(99,102,241,0.35)", marginTop: 4 }}
          >
            Další slovo →
          </button>
        )}

        {/* Streak celebration */}
        {celebrating && (
          <div style={{ position: "fixed", inset: 0, display: "flex", alignItems: "center", justifyContent: "center", pointerEvents: "none", zIndex: 50 }}>
            <div style={{ textAlign: "center" }} className="anim-pop">
              <div style={{ fontSize: 64, marginBottom: 8 }}>🔥</div>
              <div style={{ background: "#f59e0b", color: "white", fontFamily: "var(--font-display)", fontSize: 24, padding: "10px 28px", borderRadius: 24, boxShadow: "0 8px 32px rgba(245,158,11,0.4)" }}>
                Série {streak}!
              </div>
            </div>
          </div>
        )}
      </main>

      {/* Settings Modal */}
      {settingsOpen && (
        <div
          style={{ position: "fixed", inset: 0, background: "rgba(0,0,0,0.45)", backdropFilter: "blur(4px)", display: "flex", alignItems: "flex-end", justifyContent: "center", zIndex: 200, padding: 16 }}
          onClick={e => { if (e.target === e.currentTarget) setSettingsOpen(false); }}
        >
          <div style={{ background: "white", borderRadius: "28px 28px 20px 20px", width: "100%", maxWidth: 420, padding: 24, boxShadow: "0 -4px 40px rgba(0,0,0,0.15)" }} className="anim-slide-up">
            <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 20 }}>
              <h3 style={{ fontFamily: "var(--font-display)", fontSize: 24, color: "#1e293b" }}>Nastavení</h3>
              <button onClick={() => setSettingsOpen(false)} style={{ fontSize: 22, color: "#94a3b8", background: "none" }}>✕</button>
            </div>

            <p style={{ fontSize: 13, fontWeight: 700, color: "#94a3b8", marginBottom: 10, textTransform: "uppercase", letterSpacing: 1 }}>Obtížnost</p>
            <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 10, marginBottom: 20 }}>
              {[1, 2].map(l => (
                <button
                  key={l}
                  onClick={() => { setLevel(l); restartWith(allWords, selectedFilter); setSettingsOpen(false); }}
                  style={{ padding: 16, borderRadius: 18, border: level === l ? "2.5px solid #6366f1" : "2px solid #e2e8f0", background: level === l ? "#e0e7ff" : "white", textAlign: "left", transition: "all 0.2s" }}
                >
                  <div style={{ fontFamily: "var(--font-display)", fontSize: 18, color: "#1e293b", marginBottom: 4 }}>Level {l}</div>
                  <div style={{ fontSize: 12, color: "#64748b", marginBottom: 8 }}>{l === 1 ? "Jen i / y" : "i, í, y, ý"}</div>
                  <div style={{ display: "flex", gap: 4 }}>
                    {(l === 1 ? ["i","y"] : ["i","í","y","ý"]).map(o => (
                      <span key={o} style={{ background: "#f1f5f9", color: "#475569", padding: "2px 8px", borderRadius: 8, fontSize: 13, fontWeight: 700 }}>{o}</span>
                    ))}
                  </div>
                </button>
              ))}
            </div>

            <p style={{ fontSize: 13, fontWeight: 700, color: "#94a3b8", marginBottom: 10, textTransform: "uppercase", letterSpacing: 1 }}>Filtr skupin</p>
            <div style={{ display: "flex", flexWrap: "wrap", gap: 8, marginBottom: 20 }}>
              {["ALL", "B", "L", "M", "P", "S", "V", "Z"].map(f => (
                <button
                  key={f}
                  onClick={() => { setSelectedFilter(f); restartWith(allWords, f); setSettingsOpen(false); }}
                  style={{ padding: "8px 16px", borderRadius: 14, border: selectedFilter === f ? "2px solid #6366f1" : "2px solid #e2e8f0", background: selectedFilter === f ? "#e0e7ff" : "white", fontWeight: 700, fontSize: 14, color: selectedFilter === f ? "#3730a3" : "#64748b", transition: "all 0.15s" }}
                >
                  {f === "ALL" ? "Vše" : `Skupina ${f}`}
                </button>
              ))}
            </div>

            <div style={{ borderTop: "1px solid #f1f5f9", paddingTop: 14, textAlign: "center" }}>
              <p style={{ fontSize: 12, color: "#94a3b8" }}>
                📚 Načteno slov: <strong>{allWords.length}</strong> · Připraveno pro 7 000+
              </p>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
