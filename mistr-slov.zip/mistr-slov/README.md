# 🎓 Mistr vyjmenovaných slov

Interaktivní webová aplikace pro procvičování českých vyjmenovaných slov.

---

## 📁 Struktura projektu

```
mistr-slov/
├── public/
│   ├── words.json        ← DATABÁZE SLOV (přidávej sem!)
│   └── favicon.svg
├── src/
│   ├── App.jsx           ← hlavní logika hry
│   ├── main.jsx
│   └── index.css
├── index.html
├── package.json
├── vite.config.js
└── netlify.toml
```

---

## 🚀 Jak nasadit na web (bez příkazové řádky)

### Krok 1 – Založ si GitHub účet
1. Jdi na **github.com** → klikni **Sign up**
2. Zadej email, heslo, username

### Krok 2 – Vytvoř nový repozitář
1. Po přihlášení klikni na zelené tlačítko **New** (vlevo nahoře)
2. Název: `mistr-slov`
3. Nech vše ostatní jak je → klikni **Create repository**

### Krok 3 – Nahraj soubory
1. Na stránce repozitáře klikni **uploading an existing file**
2. Přetáhni VŠECHNY soubory z této složky (celý obsah `mistr-slov/`)
3. ⚠️ Pozor: složky musíš nahrát se správnou strukturou!
   - Nejjednodušší: nahrávej soubor po souboru se správnou cestou
   - Nebo použij GitHub Desktop (zdarma) pro drag & drop celé složky
4. Klikni **Commit changes**

### Krok 4 – Připoj Netlify
1. Jdi na **netlify.com** → Sign up (přihlaš se přes GitHub)
2. Klikni **Add new site** → **Import an existing project**
3. Vyber **GitHub** → povol přístup → vyber repozitář `mistr-slov`
4. Nastavení buildu:
   - Build command: `npm run build`
   - Publish directory: `dist`
5. Klikni **Deploy site**
6. Za ~2 minuty máš odkaz! (např. `mistr-slov-123.netlify.app`)

---

## ➕ Jak přidat více slov

Stačí upravit soubor `public/words.json` – přidej objekty ve formátu:

```json
{
  "slovo": "b_t",
  "spravnaVazba": "ý",
  "kontextovaVeta": "Chci b_t dobrým člověkem.",
  "kategorie": "B",
  "emoji": "🌟",
  "oduvodneni": "Být (existovat) – vyjmenované slovo BÝT."
}
```

**Kategorie:** B, L, M, P, S, V, Z

Po uložení změn na GitHub se Netlify automaticky znovu nasadí!

---

## 🎮 Funkce aplikace

- **Level 1**: výběr mezi i / y
- **Level 2**: výběr mezi i / í / y / ý  
- Filtr podle skupin (B, L, M, P, S, V, Z)
- Série (streak) s animací po každých 5 správných
- Vysvětlení po špatné odpovědi
- Statistiky na konci kola
- Responzivní – funguje na mobilu i tabletu
